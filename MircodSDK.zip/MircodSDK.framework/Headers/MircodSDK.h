//
//  MircodSDK.h
//  MircodSDK
//
//  Created by Ilyas on 11.07.2018.
//  Copyright © 2018 Mircod. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MircodSDK.
FOUNDATION_EXPORT double MircodSDKVersionNumber;

//! Project version string for MircodSDK.
FOUNDATION_EXPORT const unsigned char MircodSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MircodSDK/PublicHeader.h>


